/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ice.task.pkg3;

/**
 *
 * @author RC_Student_lab
 */
class Login {
  //boolean method to check user name
    boolean checkUserName(String name) {
        
        
        //check length
        boolean has_lenght =false;
        
        if(name.length()== 5&& name.contains("_")){
            has_lenght = true;
            registerUser(has_lenght );
            return true;
        }else if(name.length()!= 5&&! name.contains("_")){
             has_lenght = false;
             registerUser(has_lenght );
        }
        
        
        return false;

    }
    
    public String registerUser(boolean has_lenght ){
        
        
        
        if(has_lenght){
            
            System.out.println("username successfully captured");
           
        }
        else if(!has_lenght){
             System.out.println("Username is not \n" +
"correctly formatted, \n" +
"please ensure that \n" +
"your username \n" +
"contains an \n" +
"underscore and is no \n" +
"more than 5 \n" +
"characters in length .");
           
                     
        }
        return null;
     
        
    }

    boolean checkPasswordComplexity(String password) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        
    }
}