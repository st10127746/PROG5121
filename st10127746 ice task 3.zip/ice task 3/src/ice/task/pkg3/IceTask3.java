/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ice.task.pkg3;

import java.util.Scanner;

/**
 *
 * @author RC_Student_lab
 */
public class IceTask3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
 // TODO code application logic here
        
        //method to prompt the user
        register_user();
    }
    
    //method to register the user
    private static void register_user(){
        
        //declaring variables & scanner
        Scanner input = new Scanner(System.in);
        String username,
                first_name,
                last_name,
                password;
        
        //class login object 
        Login verify = new Login();
        
        //prompting the user
        System.out.print("Enter first name: ");
        first_name = input.nextLine();
       
        System.out.print("Enter last name: ");
        last_name = input.nextLine();
        
        //do while loop
        do{
            System.out.print("Enter username: ");
            username = input.nextLine(); 
            
         }while(verify.checkUserName(username)!= true);
        
       System.out.print("Enter Password:");
       password= input.nextLine();
       
       System.out.println(PassCheck(password));
       System.out.println("");
    }
    
    public static String PassCheck (String Password) {

		String result = "Password successfully captured";			// Sets the initial result as valid
		int length = 0;						
		int numCount = 0;					
		int capCount = 0;					

		for (int k =0; k < Password.length(); k++) {
			if ((Password.charAt(k) >= 47 && Password.charAt(k) <= 58) || (Password.charAt(k) >= 64 && Password.charAt(k) <= 91) ||
				(Password.charAt(k) >= 97 && Password.charAt(k) <= 122)) {
					//Keep the Password
				} else {
					result = "Password Contains Invalid Character!";		//Checks that password contains only letters and numbers
				}

			if ((Password.charAt(k) > 47 && Password.charAt(k) < 58)) {			// Counts the number of numbers
				numCount ++;
			}

			if ((Password.charAt(k) > 64 && Password.charAt(k) < 91)) {			// Counts the number of capital letters
				capCount ++;
			}

			length = (k + 1);								// Counts the passwords length

		} // Ends the for loop

		if (numCount < 1){									// Checks that password contains a number
			result = "password must be:\n" +
                                 "• At least eight characters long. \n" +
                                 "• Contain a capital letter\n" +
                                 "• Contain a number\n" +
                                 "• Contain a special character";
		}

		if (capCount < 1) {									// Checks that password contains  capital letter
			result = "password must be:\n" +
                                 "• At least eight characters long. \n" +
                                 "• Contain a capital letter\n" +
                                 "• Contain a number\n" +
                                 "• Contain a special character";
		}

		if (length < 8){									// Checks that password is long enough
			result = "password must be:\n" +
                                 "• At least eight characters long. \n" +
                                 "• Contain a capital letter\n" +
                                 "• Contain a number\n" +
                                 "• Contain a special character";
		}

			return (result);
        
    
        
        
        
    }

    private static boolean checkPasswordComplexity(String password) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        
    }
   
 }

 
    
    
